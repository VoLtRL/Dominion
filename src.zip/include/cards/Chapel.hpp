#pragma once
#include "../abstract/Card.hpp"
#include "../abstract/Action.hpp"

class Chapel : public Card, public Action {
    public:
        Chapel() : Card("Chapel", 2," Trash up to 4 cards from your hand.", {CardType::ACTION}) {}
        void play(Game& g, Player& p) const;
};