#pragma once
#include "../abstract/Card.hpp"
#include "../abstract/CardType.hpp"
#include "../abstract/Action.hpp"

class Remodel : public Card, public Action  {
    public:
        Remodel() : Card("Remodel", 4, "Trash a card from your hand. Gain a card costing up to 2 more than it.", {CardType::ACTION}) {}
        void play(Game& g, Player& p) const;
};