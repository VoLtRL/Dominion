#include "client/network/NetworkManager.hpp"
NetworkManager::NetworkManager(const ClientPreferences &clientPreferences, QObject *parent) : clientPreferences(clientPreferences), QObject(parent), m_socket(this){
    connect(&m_socket, &QTcpSocket::connected, this, &NetworkManager::onConnected);
    connect(&m_socket, &QTcpSocket::disconnected, this, &NetworkManager::onDisconnected);
    connect(&m_socket, &QTcpSocket::readyRead, this, &NetworkManager::onReadyRead);
    connect(&m_socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::errorOccurred),
            this, &NetworkManager::onErrorOccurred);
}

QAbstractSocket::SocketState NetworkManager::getState() const {
    return m_socket.state();
}

void NetworkManager::onConnected() {
    emit connected();
}

void NetworkManager::onDisconnected() {
    emit disconnected();
}

void NetworkManager::onReadyRead() {
    while (m_socket.canReadLine()) {
    QByteArray line = m_socket.readLine();
    QJsonDocument doc = QJsonDocument::fromJson(line);
    if (!doc.isObject()) {
        emit connectionError("Received invalid JSON from server.");
        continue;
    
    }
    QJsonObject data = doc.object();
    emit actionReceived(stringToActionType(data["action"].toString().toStdString()), data["data"].toObject());
    }
}

void NetworkManager::onErrorOccurred(QAbstractSocket::SocketError socketError) {
    emit connectionError(m_socket.errorString());
}

void NetworkManager::connectToServer() {
    if (m_socket.state() != QAbstractSocket::UnconnectedState) {
        m_socket.abort();
    }
    m_socket.connectToHost(clientPreferences.getHostAddress(), clientPreferences.getHostPort());
}

void NetworkManager::disconnectFromServer() {
    m_socket.disconnectFromHost();
}

void NetworkManager::sendAction(const ActionType &action, const Network::Payload &data) {
    if (m_socket.state() != QAbstractSocket::ConnectedState) {
        emit connectionError("Not connected to server.");
        return;
    }
    QJsonObject message;
    message["action"] = actionTypeToString(action).c_str();
    message["data"] = data.toJson();

    QJsonDocument doc(message);
    QByteArray toSend = doc.toJson(QJsonDocument::Compact) + '\n';
    qDebug() << "Sending JSON: " << toSend.toStdString();
    m_socket.write(toSend);

}
